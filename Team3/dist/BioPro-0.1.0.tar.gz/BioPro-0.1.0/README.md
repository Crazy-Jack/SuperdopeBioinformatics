# Predicting Biochemical Pathways Involving Target RBP



## Install


### Install via source code

To install via source code, clone our github repo and run:

`bash install.sh`


### Install via pip

Or you can directly install our software from pip:

`pip install BioPro`
